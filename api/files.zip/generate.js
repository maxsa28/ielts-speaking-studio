export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { userInput } = req.body;
  if (!userInput) return res.status(400).json({ error: 'Missing userInput' });

  const prompt = `你是一位雅思口语备考专家。用户用中文描述了一段内容，请你为该内容生成雅思口语6.5、7、7.5、8、8.5、9分六个段位的英文口语范文。

用户输入（中文）：${userInput}

请严格按照以下JSON格式返回，不要有任何其他文字：
{
  "scores": [
    {
      "band": "6.5",
      "text": "...(对应分数的英语口语范文，2-4句，自然口语风格)",
      "phrases": [
        {"en": "phrase", "zh": "中文释义", "usage": "使用场景说明"}
      ]
    }
  ]
}

要求：
1. 每个分段的范文要真实体现该分数段的词汇水平、句式复杂度和流利度差异
2. 越高分的范文越地道、词汇越高级、表达越自然
3. phrases中的词组必须真实出现在该段范文中，用<b>标签加粗标记在text中
4. 范文要口语化，不要太书面
5. 每个分数段提供4-6个高频词组
6. 必须返回全部6个分数段`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
}
